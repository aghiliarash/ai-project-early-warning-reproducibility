# Adverse project outcome

The primary outcome must be coded before model development and observed only after the predictor window closes. Eligible events may include cancellation, suspension, predefined major redesign, severe budget or schedule failure, or failure against a pre-specified adoption milestone. Predictor-window complaints, grievances, resistance scores, and escalation records must not be included in outcome coding.
