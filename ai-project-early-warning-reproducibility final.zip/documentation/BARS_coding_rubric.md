# BARS coding rubric

Use the study-specific approved rubric here before restricted-data analysis. Record source document, event date, project identifier, coding decision, coder identifier, and rationale. Independent coders must remain blinded to post-predictor adverse-outcome status until reliability estimation is complete. This public template intentionally contains no confidential examples.
