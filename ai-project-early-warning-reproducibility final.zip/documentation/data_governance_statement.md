# Data governance statement

The public repository contains no original archival record, interview transcript, employee identifier, organization name, or re-identification key. Synthetic demonstration data are artificial and are not calibrated to reproduce original study results.
