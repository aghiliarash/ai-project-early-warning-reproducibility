# Controlled-access protocol

Requests must include a research proposal, institutional affiliation, data-security plan, and ethics documentation where applicable. Release requires written organizational permission, a data-use agreement, de-identification review, and confirmation that requested analyses cannot be completed using public documentation or synthetic demonstration data. No employee-identifiable materials may be released.
