from pathlib import Path
import numpy as np
import pandas as pd

rng=np.random.default_rng(20260714)
out=Path(__file__).resolve().parents[1]/'data'/'synthetic_demo_data.csv'
org=np.repeat(np.arange(1,115), rng.integers(2,4,114))[:307]
rng.shuffle(org)
n=len(org)
country=rng.choice(['Romania','Turkiye'],n)
industry=rng.choice(['Manufacturing','Health','Construction','Services'],n)
ai=np.clip(rng.normal(50,18,n),0,100)
gov=np.clip(rng.normal(50,17,n),0,100)
bars=rng.integers(1,8,n)
res=np.clip(8*bars+rng.normal(0,12,n),0,100)
logit=-4.0+.030*ai+.040*res-.012*gov+rng.normal(0,.55,n)
p=1/(1+np.exp(-logit))
y=rng.binomial(1,p)
psi=np.clip(78-18*y-.10*res+.08*gov+rng.normal(0,8,n),0,100)
df=pd.DataFrame({'organization_id':org.astype(str),'country':country,'industry':industry,'ai_deployment_conditions':ai,'governance_enactment_capacity':gov,'documented_resistance_signals':res,'bars_raw':bars,'adverse_project_outcome':y,'project_success_index_truncated':psi})
for c in ['ai_deployment_conditions','governance_enactment_capacity','documented_resistance_signals']:
    df.loc[rng.random(n)<.06,c]=np.nan
df.to_csv(out,index=False)
print(f'Wrote demonstration-only synthetic data: {out}')
