from pathlib import Path
import numpy as np
import pandas as pd

root=Path(__file__).resolve().parents[1]
df=pd.read_csv(root/'data'/'synthetic_demo_data.csv')
rng=np.random.default_rng(20260714)
records=[]
for b in range(1000):
    x=df.sample(len(df),replace=True,random_state=int(rng.integers(1,2**31-1)))
    rates=x.groupby('bars_raw').adverse_project_outcome.mean()
    if len(rates)>2:
        diffs=rates.diff().abs().dropna(); records.append({'bootstrap':b,'candidate_bars':int(diffs.idxmax())})
out=pd.DataFrame(records)
out.to_csv(root/'outputs/tables'/'candidate_threshold_bootstrap_demo.csv',index=False)
print('Exploratory synthetic threshold bootstrap completed. Do not treat as external validation.')
