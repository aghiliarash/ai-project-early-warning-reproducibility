from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedGroupKFold, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, precision_score, recall_score, f1_score, confusion_matrix, roc_curve
from sklearn.inspection import permutation_importance, PartialDependenceDisplay
from sklearn.calibration import calibration_curve
from sklearn.linear_model import LogisticRegression

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
df=pd.read_csv(root/'data'/'synthetic_demo_data.csv')
features=['ai_deployment_conditions','governance_enactment_capacity','documented_resistance_signals','bars_raw']
X=df[features]; y=df['adverse_project_outcome'].astype(int); groups=df['organization_id'].astype(str)
outer=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=20260714)
rows=[]; importances=[]; probs=np.full(len(df),np.nan)
for fold,(tr,te) in enumerate(outer.split(X,y,groups),1):
    inner=StratifiedGroupKFold(n_splits=3,shuffle=True,random_state=100+fold)
    pipe=Pipeline([('imputer',IterativeImputer(random_state=fold,max_iter=20)),('rf',RandomForestClassifier(random_state=fold,class_weight='balanced'))])
    grid=GridSearchCV(pipe,{'rf__n_estimators':[300,500],'rf__max_depth':[3,5,None],'rf__min_samples_leaf':[2,5]},cv=inner,scoring='roc_auc',n_jobs=-1)
    grid.fit(X.iloc[tr],y.iloc[tr],groups=groups.iloc[tr])
    p=grid.predict_proba(X.iloc[te])[:,1]; pred=(p>=.5).astype(int); probs[te]=p
    tn,fp,fn,tp=confusion_matrix(y.iloc[te],pred,labels=[0,1]).ravel()
    rows.append({'fold':fold,'roc_auc':roc_auc_score(y.iloc[te],p),'pr_auc':average_precision_score(y.iloc[te],p),'brier':brier_score_loss(y.iloc[te],p),'sensitivity':recall_score(y.iloc[te],pred,zero_division=0),'specificity':tn/(tn+fp) if tn+fp else np.nan,'precision':precision_score(y.iloc[te],pred,zero_division=0),'f1':f1_score(y.iloc[te],pred,zero_division=0),'n_test':len(te)})
    pi=permutation_importance(grid.best_estimator_,X.iloc[te],y.iloc[te],n_repeats=30,random_state=fold,scoring='roc_auc')
    importances.extend([{'fold':fold,'feature':f,'importance':v} for f,v in zip(features,pi.importances_mean)])
metrics=pd.DataFrame(rows); imp=pd.DataFrame(importances)
(root/'outputs/tables').mkdir(parents=True,exist_ok=True); (root/'outputs/figures').mkdir(parents=True,exist_ok=True)
metrics.to_csv(root/'outputs/tables'/'cv_metrics_by_fold.csv',index=False)
metrics.agg(['mean','std']).T.to_csv(root/'outputs/tables'/'cv_metric_summary.csv')
imp.groupby('feature').importance.agg(['mean','std','count']).sort_values('mean',ascending=False).to_csv(root/'outputs/tables'/'permutation_importance_summary.csv')
cal_y,cal_p=calibration_curve(y,probs,n_bins=6,strategy='quantile')
plt.figure(figsize=(6,5)); plt.plot([0,1],[0,1],'--',color='gray'); plt.plot(cal_p,cal_y,'o-'); plt.xlabel('Mean predicted risk'); plt.ylabel('Observed outcome proportion'); plt.title('Cross-validated calibration: synthetic demonstration'); plt.tight_layout(); plt.savefig(root/'outputs/figures'/'calibration.png',dpi=180); plt.close()
summary=df.groupby('bars_raw').adverse_project_outcome.agg(['count','mean']).reset_index(); summary.to_csv(root/'outputs/tables'/'bars_support_and_outcomes.csv',index=False)
plt.figure(figsize=(6,5)); plt.bar(summary.bars_raw,summary['count']); plt.xlabel('Raw BARS'); plt.ylabel('Projects'); plt.title('BARS support: synthetic demonstration'); plt.tight_layout(); plt.savefig(root/'outputs/figures'/'bars_support.png',dpi=180); plt.close()
print(metrics.agg(['mean','std']).T.round(3))
print('Outputs written to outputs/. Demonstration-only results are not manuscript estimates.')
