from pathlib import Path
import pandas as pd
import statsmodels.formula.api as smf

root=Path(__file__).resolve().parents[1]
df=pd.read_csv(root/'data'/'synthetic_demo_data.csv')
model=smf.logit('adverse_project_outcome ~ ai_deployment_conditions + governance_enactment_capacity + documented_resistance_signals + bars_raw',data=df.dropna()).fit(disp=False,cov_type='cluster',cov_kwds={'groups':df.dropna()['organization_id']})
(root/'outputs/tables'/'clustered_logit_summary.txt').write_text(model.summary().as_text())
print('Organization-clustered associational model saved. Coefficients are not causal estimates.')
