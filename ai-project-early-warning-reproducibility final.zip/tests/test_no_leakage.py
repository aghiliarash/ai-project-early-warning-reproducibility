from sklearn.model_selection import StratifiedGroupKFold
import pandas as pd
from pathlib import Path
root=Path(__file__).resolve().parents[1]
df=pd.read_csv(root/'data'/'synthetic_demo_data.csv')
cv=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=1)
for tr,te in cv.split(df,df.adverse_project_outcome,df.organization_id):
    assert not set(df.organization_id.iloc[tr]).intersection(set(df.organization_id.iloc[te]))
print('No organization appears in both train and test folds.')
